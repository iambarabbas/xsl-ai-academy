# Design System Specification

## 1. Overview & Creative North Star: "The Illuminated Scholar"
This design system moves beyond the cold, clinical aesthetic typical of AI platforms to create a high-end, editorial experience. Inspired by the intersection of prestigious academia and modern digital craftsmanship, our Creative North Star is **"The Illuminated Scholar."**

We achieve this through "The Breathing Canvas"—a layout strategy that prioritizes generous white space (120px+ vertical rhythm) and intentional asymmetry. By utilizing high-contrast typography scales and sophisticated tonal layering, we break the "template" look. Instead of rigid boxes, we treat the UI as a series of curated, floating surfaces that invite the user into a space of focused learning and quiet authority.

---

## 2. Colors & Surface Philosophy
The palette balances the deep, authoritative weight of `secondary` (Navy) with the vibrant, intellectual energy of `tertiary_fixed` (Gold) and `on_primary_container` (Orange).

### Color Tokens
*   **Primary (Action):** `#2b1400` (Deep Earth Tone) / **Accent:** `#F5921E` (Warm Orange)
*   **Secondary (Brand/Header):** `#1B2B5E` (Deep Navy)
*   **Tertiary (Accent):** `#F5C518` (Gold/Yellow)
*   **Neutral Backgrounds:** `surface` (#faf9fc) and `surface_container_lowest` (#ffffff)

### The "No-Line" Rule
To maintain a premium feel, **1px solid borders are prohibited for sectioning.** Boundaries between sections must be defined solely through background color shifts. For example, a `surface_container_low` section should sit directly against a `surface` background to create a clean, modern break without visual clutter.

### Surface Hierarchy & Nesting
Treat the UI as physical layers. Use the following hierarchy to define depth:
1.  **Base Layer:** `surface` (#faf9fc) - The main canvas.
2.  **Mid Layer:** `surface_container_low` (#f4f3f6) - Used for grouping content sections.
3.  **Top Layer:** `surface_container_lowest` (#ffffff) - Reserved for interactive cards and elevated components.

### The "Glass & Gradient" Rule
For hero sections and primary CTAs, use subtle gradients transitioning from `primary` to `primary_container`. For floating navigation or over-image UI, apply **Glassmorphism**: semi-transparent `surface` colors with a 20px backdrop-blur to allow brand colors to bleed through softly.

---

## 3. Typography
Our typography is a dialogue between the modern, geometric `Plus Jakarta Sans` and the highly legible, functional `Inter`.

| Level | Token | Font | Size | Weight | Character Spacing |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-lg` | Plus Jakarta Sans | 3.5rem | 700 | -0.02em |
| **Headline** | `headline-lg` | Plus Jakarta Sans | 2rem | 700 | -0.01em |
| **Title** | `title-lg` | Inter | 1.375rem | 600 | 0 |
| **Body** | `body-lg` | Inter | 1rem | 400 | 0 |
| **Label** | `label-md` | Inter | 0.75rem | 600 | 0.05em (Caps) |

**Editorial Intent:** Use `display-lg` for impactful, short value propositions. The contrast between the bold, tight-tracking headers and the airy, Slate Grey (`on_surface_variant`) body text conveys a "Masterclass" level of credibility.

---

## 4. Elevation & Depth
This system rejects traditional structural lines in favor of **Tonal Layering.**

*   **The Layering Principle:** Depth is achieved by "stacking." Place a white card (`surface_container_lowest`) on a light grey section (`surface_container_low`) to create a natural lift.
*   **Ambient Shadows:** For floating elements, use a "Cloud Shadow": 
    *   `box-shadow: 0 20px 40px rgba(27, 43, 94, 0.06);` 
    *   *Note:* The shadow color is a tinted version of our Navy (`secondary`), not black, to mimic natural light.
*   **The "Ghost Border" Fallback:** If a container requires definition against a white background, use the `outline_variant` token at **20% opacity**. 100% opaque borders are strictly forbidden.

---

## 5. Components

### Buttons
*   **Primary:** Uppercase, `tertiary_fixed_dim` (Gold) or Warm Orange background. 8px radius (`DEFAULT`). Text weight 600.
*   **Secondary:** Ghost style. Outline variant at 20% opacity. 8px radius.
*   **States:** On hover, primary buttons should shift 2px upwards with a soft ambient shadow increase.

### Cards
*   **Styling:** 12px radius (`md`), white background (`surface_container_lowest`).
*   **Rule:** **No Divider Lines.** Use vertical white space (32px - 48px) to separate card headers from body content. 
*   **Interactive:** On hover, apply a 1px `outline_variant` (at 20%) to subtly define the edge as it lifts.

### Input Fields
*   **Styling:** 8px radius, pure white background, `outline_variant` (20%) border.
*   **Focus State:** Border color shifts to `secondary` (Navy) with a 2px soft outer glow in the same hue.

### Signature Component: The "Learning Track" List
Instead of standard bullet points, use thin white-line icons inside `primary_container` (Navy) circular badges. List items are separated by 24px of white space, never by horizontal rules.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical layouts (e.g., a 2-column grid where one column is offset by 40px vertically).
*   **Do** allow for at least 120px of padding between major sections to let the design breathe.
*   **Do** use "thin-stroke" icons (1px or 1.5px weight) to match the premium editorial feel.

### Don't
*   **Don't** use pure black (#000000) for text. Always use Deep Navy or Slate Grey (`on_surface_variant`).
*   **Don't** use standard drop shadows. If it looks like a "box shadow," it’s too heavy. It should look like "ambient light."
*   **Don't** use 100% opaque borders to separate content. Use tonal shifts or white space.
*   **Don't** cram content. If a section feels "busy," increase the padding and reduce the font size of the body copy.