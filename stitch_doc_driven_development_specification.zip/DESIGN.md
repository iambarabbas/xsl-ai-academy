# Design System Specification: The Prestigious Library

## 1. Creative North Star: The Prestigious Library
This design system is anchored in the concept of **"The Prestigious Library."** It is an editorial-first framework designed to evoke the quiet authority of a private ivy-league archive. We are moving away from the "SaaS-template" look by embracing high-contrast typographic scales, intentional asymmetry, and a focus on atmospheric depth. 

The goal is to make the user feel like a curator rather than a consumer. We achieve this by prioritizing "white space" (specifically our cream-toned `surface` space) and treating every interface element as a thoughtful piece of academic documentation.

---

## 2. Color & Tonal Layering
The palette is rooted in a foundation of Deep Navy and Emerald Green, supported by a sophisticated range of cream neutrals.

### The "No-Line" Rule
To maintain a premium, editorial feel, **1px solid borders are prohibited for sectioning.** Boundaries must be defined through background color shifts. Use `surface-container-low` for large content sections sitting atop a `surface` background. If you need to distinguish an inner element, move one tier up the hierarchy (e.g., a `surface-container-highest` card within a `surface-container-low` section).

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—stacked sheets of fine parchment or heavy cardstock.
- **Base Level:** `surface` (#faf9f4) – The primary canvas.
- **Primary Containers:** `surface-container-low` (#f5f4ef) – Use for sidebars or secondary content regions.
- **Interactive Layers:** `surface-container-lowest` (#ffffff) – Reserved for primary content cards or "floated" editorial pieces to create a crisp, high-end contrast against the cream base.

### Signature Textures: The "Emerald Glow"
While we avoid harsh gradients, use a subtle **Signature Texture** for primary CTAs and hero backgrounds. Transition from `primary` (#021549) to `primary_container` (#1B2B5E) at a 135-degree angle. This provides a deep, "velvet" finish that flat color cannot replicate.

---

## 3. Typography: The Editorial Voice
The system utilizes a high-contrast pairing of **Plus Jakarta Sans** for authority and **Inter** for modern utility.

| Token | Font Family | Size | Character | Use Case |
| :--- | :--- | :--- | :--- | :--- |
| **display-lg** | Plus Jakarta Sans | 3.5rem | Bold | Hero statements; high-impact landing areas. |
| **headline-md** | Plus Jakarta Sans | 1.75rem | Semi-Bold | Section headers; scholarly sub-titles. |
| **title-lg** | Inter | 1.375rem | Medium | Article titles; featured card headings. |
| **body-lg** | Inter | 1rem | Regular | Main reading experience; high legibility. |
| **label-md** | Inter | 0.75rem | Semi-Bold | Metadata; "Micro-copy" for academic citations. |

*Director’s Note: Always favor generous line-height (1.6 for body text) to ensure the interface feels "breathable" and academic.*

---

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering** rather than traditional structural lines.

- **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural lift without a shadow.
- **Ambient Shadows:** For floating elements (modals, dropdowns), use a custom "Scholar Shadow": `box-shadow: 0 12px 32px rgba(27, 28, 25, 0.05)`. This uses a tinted version of the `on_surface` color to mimic natural, ambient light.
- **The "Ghost Border" Fallback:** If a border is essential for accessibility, use the `outline_variant` token at **15% opacity**. This creates a "watermark" effect rather than a hard boundary.
- **Glassmorphism:** For top navigation bars or floating action menus, use `surface_bright` with a 70% opacity and a `backdrop-filter: blur(12px)`. This allows the scholarly "cream" tones to bleed through, softening the layout.

---

## 5. Components

### Buttons
- **Primary:** `secondary` (#1b6b51) background with `on_secondary` (#ffffff) text. Use `xl` (0.75rem) roundedness. 
- **Secondary:** `surface_container_highest` background with `primary` text. No border.
- **Tertiary:** No background. `primary` text with a subtle underline of `secondary` (#1b6b51) on hover.

### Cards & Lists
- **Rule:** Forbid the use of divider lines.
- **Implementation:** Separate list items using the spacing scale (e.g., 1rem padding) and use a `surface_container_low` background on hover to indicate interactivity.
- **Academic Cards:** Use `surface_container_lowest` (#ffffff) with an `xl` corner radius (0.75rem). Align text asymmetrically to create a modern, editorial look.

### Input Fields
- **Styling:** Use `surface_container_low` for the input fill. 
- **Active State:** On focus, the field should transition to `surface_container_lowest` with a "Ghost Border" of `secondary` (#1b6b51) at 40% opacity.

### Navigation (The Curator's Rail)
- Vertical navigation should use a `primary_container` (#1B2B5E) background with `on_primary` text. This provides a "weighted" anchor to the layout, reflecting the spines of books on a library shelf.

---

## 6. Do’s and Don’ts

### Do:
- **Do** use large, sweeping margins. If you think there is enough white space, add 20% more.
- **Do** use `secondary` (Emerald) sparingly. It is a "spark" color for CTAs and critical data points, not a background color for large sections.
- **Do** nest surfaces. A white card on a cream background is our signature "High-End" look.

### Don’t:
- **Don’t** use 100% black (#000000). Always use `on_surface` (#1b1c19) or `primary` (#021549) for text to maintain visual warmth.
- **Don’t** use harsh gradients or "gamified" animations. All transitions should be eased (cubic-bezier 0.4, 0, 0.2, 1) and subtle.
- **Don’t** use dividers to separate content. Use the Spacing Scale to create "islands of information."

---

## 7. Spacing Scale
Our spacing is built on a 4px base, but we prioritize the larger "Editorial" increments to maintain the North Star:
- **Compact:** 8px (Labels, small padding)
- **Standard:** 16px (Body padding, card internals)
- **Breathable:** 32px (Section spacing, container margins)
- **Grand:** 64px+ (Hero margins, major page transitions)